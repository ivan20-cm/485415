// 遊戲邏輯與 Teachable Machine 辨識分開，辨識結果是唯一計分來源。
class ColorRound {
  constructor() { this.duration = 30_000; this.threshold = 0.85; this.holdMs = 500; this.running = false; this.score = 0; this.target = 'Red'; this.matchSince = null; this.deadline = 0; }
  start(now, initial = 'Red') { this.running = true; this.score = 0; this.target = initial; this.matchSince = null; this.deadline = now + this.duration; }
  finish() { this.running = false; this.matchSince = null; }
  remaining(now) { return this.running ? Math.max(0, Math.ceil((this.deadline-now)/1000)) : 0; }
  consume(label, probability, now) {
    if (!this.running) return {type:'idle', progress:0};
    if (now >= this.deadline) { this.finish(); return {type:'expired', progress:0}; }
    if (label !== this.target || probability < this.threshold) { this.matchSince = null; return {type:'waiting', progress:0}; }
    if (this.matchSince === null) this.matchSince = now;
    const elapsed = now-this.matchSince;
    if (elapsed < this.holdMs) return {type:'holding', progress:Math.min(1,elapsed/this.holdMs)};
    this.score += 1;
    this.target = this.target === 'Red' ? 'Blue' : 'Red';
    this.matchSince = null;
    return {type:'score', progress:0};
  }
}

window.addEventListener('DOMContentLoaded', () => {
  'use strict';
  const $ = id => document.getElementById(id);
  const names = {Red:'紅色色卡', Blue:'藍色色卡', Neutral:'非色卡'};
  const game = new ColorRound();
  const canvas = $('camera');
  const context = canvas.getContext('2d');
  const video = document.createElement('video');
  video.setAttribute('playsinline',''); video.muted = true; video.autoplay = true;
  let model = null, stream = null, cameraReady = false, busy = false, frameId = null, session = 0, lastPredictAt = 0;
  let best = 0;
  try { best = Number(localStorage.getItem('swp08-color-best')) || 0; } catch (_) {}
  $('best').textContent = best;
  function status(message, error = false) { $('status').textContent = message; $('status').className = `status${error ? ' error' : ''}`; }
  function setTarget() { const red = game.target === 'Red'; $('target-card').textContent = red ? '紅色' : '藍色'; $('target-card').className = `color-card ${red ? 'red' : 'blue'}`; }
  function finishRound(reason, expired = false) {
    if (!game.running && !expired) return;
    game.finish();
    if (game.score > best) { best = game.score; $('best').textContent = best; try {localStorage.setItem('swp08-color-best',String(best));} catch (_) {} }
    $('start').disabled = !cameraReady; $('start').textContent = '再玩一次'; $('end').disabled = true;
    $('hold-progress').style.width = '0%';
    $('feedback').textContent = `${reason}本局 ${game.score} 分。${cameraReady ? '按「再玩一次」重新挑戰。' : ''}`;
  }
  function handlePredictions(predictions, now) {
    // 明確依模型的 label 對應，不依賴陣列排列順序。
    const values = {Red:0,Blue:0,Neutral:0};
    for (const p of predictions) if (Object.prototype.hasOwnProperty.call(values,p.className)) values[p.className] = Number.isFinite(p.probability) ? Math.max(0,Math.min(1,p.probability)) : 0;
    const sorted = Object.entries(values).sort((a,b)=>b[1]-a[1]);
    const [label,probability] = sorted[0];
    for (const key of Object.keys(values)) { const pct = (values[key]*100).toFixed(1); $('bar-'+key.toLowerCase()).style.width = `${pct}%`; $('prob-'+key.toLowerCase()).textContent = `${pct}%`; }
    $('result').textContent = probability >= game.threshold ? names[label] : '辨識不確定';
    $('confidence').textContent = `信心 ${(probability*100).toFixed(1)}%`;
    if (!game.running) return;
    const result = game.consume(label,probability,now);
    if (result.type === 'expired') { // consume 已停止計分，接著完成畫面與最佳成績收尾。
      $('time').textContent = '0'; finishRound('時間到！', true); return;
    }
    $('hold-progress').style.width = `${result.progress*100}%`;
    if (result.type === 'score') {
      $('score').textContent = game.score;
      setTarget();
      $('feedback').textContent = `辨識成功，+1 分！換成${names[game.target]}。`;
      $('target-card').classList.remove('flash'); void $('target-card').offsetWidth; $('target-card').classList.add('flash');
    } else if (result.type === 'holding') $('feedback').textContent = '辨識到目標了，請保持穩定…';
    else if (probability < game.threshold) $('feedback').textContent = '信心不足，請讓色卡填滿畫面並保持穩定。';
    else if (label === 'Neutral') $('feedback').textContent = `請出示${names[game.target]}。`;
    else $('feedback').textContent = `目前是${names[label]}，請換成${names[game.target]}。`;
  }
  function drawCamera() {
    const width = video.videoWidth, height = video.videoHeight;
    if (!width || !height) return false;
    const side = Math.min(width,height);
    context.save(); context.translate(canvas.width,0); context.scale(-1,1);
    context.drawImage(video,(width-side)/2,(height-side)/2,side,side,0,0,canvas.width,canvas.height);
    context.restore(); return true;
  }
  async function loop(token) {
    if (!cameraReady || token !== session) return;
    try {
      const now = performance.now();
      if (drawCamera() && now-lastPredictAt >= 80) {
        lastPredictAt = now;
        const predictions = await model.predict(canvas,false);
        if (!cameraReady || token !== session) return;
        handlePredictions(predictions,performance.now());
      }
    } catch (error) {
      console.error('辨識失敗',error); shutdown(); status('辨識過程中發生錯誤。請重新開啟攝影機；若持續發生，重新整理頁面。',true); return;
    }
    frameId = requestAnimationFrame(()=>loop(token));
  }
  async function loadEmbeddedModel() {
    if (model) return model;
    if (!window.tf || !window.tmImage) throw new Error('LIBRARY_MISSING');
    const bundle = JSON.parse($('embedded-model').textContent);
    const weights = Uint8Array.from(atob(bundle.weights),char=>char.charCodeAt(0));
    const json = new File([JSON.stringify(bundle.model)],'model.json',{type:'application/json'});
    const bin = new File([weights],bundle.weightName || 'weights.bin',{type:'application/octet-stream'});
    const metadata = new File([JSON.stringify(bundle.metadata)],'metadata.json',{type:'application/json'});
    model = await tmImage.loadFromFiles(json,bin,metadata);
    const labels = model.getClassLabels();
    if (labels.length !== 3 || ['Red','Blue','Neutral'].some(label=>!labels.includes(label))) {
      if (typeof model.dispose === 'function') model.dispose(); model = null; throw new Error('LABELS_MISMATCH');
    }
    return model;
  }
  async function connect() {
    if (busy || cameraReady) return;
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) { status('攝影機需要安全連線。請用 GitHub Pages 的 HTTPS 網址，或 localhost 開啟，不要直接點擊下載檔案。',true); return; }
    busy = true; $('connect').disabled = true; $('connect').textContent = '載入模型中…';
    const token = ++session;
    try {
      status('正在載入訓練模型，首次使用可能需要一些時間…');
      await loadEmbeddedModel();
      $('connect').textContent = '等待攝影機授權…';
      const acquired = await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:640},height:{ideal:480}},audio:false});
      if (token !== session) {acquired.getTracks().forEach(track=>track.stop()); return;}
      stream = acquired; video.srcObject = stream;
      // Safari 的行動裝置需要 video 存在於文件且帶 playsinline。
      video.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:-10px'; document.body.appendChild(video);
      await video.play();
      if (token !== session) return;
      cameraReady = true; lastPredictAt = 0;
      canvas.classList.add('live'); $('camera-placeholder').hidden = true;
      $('camera-state').textContent = '辨識中'; $('stop-camera').disabled = false; $('start').disabled = false;
      $('connect').textContent = '攝影機已開啟';
      $('feedback').textContent = '先測試紅、藍色卡，再按「開始挑戰」。';
      stream.getVideoTracks().forEach(track=>track.addEventListener('ended',()=>{if(cameraReady){shutdown();status('攝影機已中斷，請重新開啟。',true);}}));
      status('模型已就緒，正在辨識 Red、Blue 與 Neutral。');
      loop(token);
    } catch (error) {
      console.error('啟動失敗',error); shutdown();
      const messages = {NotAllowedError:'攝影機權限被拒絕。請允許此網站使用攝影機，再重新開啟。', NotFoundError:'找不到攝影機，請使用有攝影機的電腦或手機。', NotReadableError:'攝影機無法使用，請關閉其他正在使用攝影機的程式再重試。'};
      status(messages[error.name] || (error.message === 'LIBRARY_MISSING' ? '辨識程式未能載入。請確認網路連線，重新整理頁面後再試。' : '模型或攝影機啟動失敗。請確認網路連線，並以 Chrome 開啟 GitHub Pages 的 HTTPS 網址。'),true);
    } finally { busy = false; if (!cameraReady) {$('connect').disabled=false; $('connect').textContent='開啟攝影機';} }
  }
  function shutdown() {
    cameraReady = false; ++session;
    if (game.running) finishRound('本局已結束。');
    if (frameId !== null) {cancelAnimationFrame(frameId); frameId = null;}
    if (stream) {stream.getTracks().forEach(track=>track.stop()); stream=null;}
    video.pause(); video.srcObject = null; video.remove();
    $('camera-state').textContent = '尚未開啟'; canvas.classList.remove('live'); $('camera-placeholder').hidden = false;
    $('connect').disabled = busy; $('connect').textContent = '開啟攝影機';
    $('stop-camera').disabled = true; $('start').disabled = true; $('end').disabled = true;
    $('result').textContent = '尚未辨識'; $('confidence').textContent = '—';
    for (const color of ['red','blue','neutral']) {$('bar-'+color).style.width='0%'; $('prob-'+color).textContent='—';}
  }
  $('connect').addEventListener('click',connect);
  $('stop-camera').addEventListener('click',()=>{shutdown();status('攝影機已關閉。');});
  $('start').addEventListener('click',()=>{
    if (!cameraReady || game.running) return;
    game.start(performance.now(),Math.random()<0.5 ? 'Red' : 'Blue');
    $('score').textContent='0'; $('time').textContent='30'; $('hold-progress').style.width='0%';
    $('start').disabled=true; $('end').disabled=false; setTarget();
    $('feedback').textContent=`挑戰開始！請出示${names[game.target]}。`;
  });
  $('end').addEventListener('click',()=>finishRound('本局已結束。'));
  setInterval(()=>{if(game.running){const now=performance.now();$('time').textContent=game.remaining(now);if(now>=game.deadline)finishRound('時間到！');}},100);
  window.addEventListener('pagehide',shutdown);
  document.addEventListener('visibilitychange',()=>{if(document.hidden && (cameraReady || busy)){shutdown();status('離開頁面後攝影機已停止，回來時請重新開啟。');}});
  for (const [name,color,label] of [['red','#e1232d','紅色'],['blue','#1e4be1','藍色'],['neutral','#e6e6e6','灰色']]) {
    $('show-'+name).addEventListener('click',()=>{ $('full-card').style.background=color; $('full-card').textContent=''; $('card-dialog').setAttribute('aria-label',label+'測試色卡'); $('card-dialog').showModal(); });
  }
  $('close-card').addEventListener('click',()=>$('card-dialog').close());
});
