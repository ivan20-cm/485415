// Train with Google's official Teachable Machine image library, not a custom color rule.
const fs=require('fs'),path=require('path'),vm=require('vm');
const {createCanvas,loadImage}=require('@napi-rs/canvas');
const root=path.resolve(__dirname,'..');
const tf=require(path.join(__dirname,'tf.min.js'));
const metadata={tfjsVersion:'1.3.1',tmVersion:'2.4.17',packageVersion:'0.8.5',packageName:'@teachablemachine/image',modelName:'SWP08 Red Blue Neutral',labels:['Red','Blue','Neutral'],imageSize:224,timeStamp:new Date().toISOString(),userMetadata:{trainingRoute:'Official @teachablemachine/image API (web trainer unresponsive)',trainingSamplesPerClass:60,heldOutSamplesPerClass:20,generatedSeed:807}};
const ctx={tf,console,Math,Date,Array,Float32Array,Uint8Array,ArrayBuffer,setTimeout,clearTimeout};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'tm-image.min.js'),'utf8'),ctx);
const tm=ctx.tmImage;
function readPixels(file){return loadImage(file).then(image=>{const c=createCanvas(224,224),g=c.getContext('2d');g.drawImage(image,0,0,224,224);const rgba=g.getImageData(0,0,224,224).data;const pixels=new Float32Array(224*224*3);for(let i=0,j=0;i<rgba.length;i+=4){pixels[j++]=rgba[i]/127-1;pixels[j++]=rgba[i+1]/127-1;pixels[j++]=rgba[i+2]/127-1;}return tf.tensor4d(pixels,[1,224,224,3]);});}
(async()=>{
 await tf.setBackend('cpu');
 const artifact=JSON.parse(fs.readFileSync(path.join(__dirname,'mobilenet.json'),'utf8'));
 const weights=fs.readFileSync(path.join(__dirname,'mobilenet.bin'));
 const originalLoader=tf.loadLayersModel;
 tf.loadLayersModel=async()=>originalLoader(tf.io.fromMemory(artifact.modelTopology,artifact.weightsManifest.flatMap(x=>x.weights),weights.buffer.slice(weights.byteOffset,weights.byteOffset+weights.byteLength)));
 const teachable=await tm.createTeachable(metadata,{version:2,alpha:0.35});
 tf.loadLayersModel=originalLoader;
 teachable.setLabels(metadata.labels);
 const start=Date.now();
 for(let c=0;c<3;c++){
  const label=metadata.labels[c];
  for(let i=1;i<=60;i++){
   await teachable.addExample(c,await readPixels(path.join(root,'training',label,`${label.toLowerCase()}-${String(i).padStart(3,'0')}.png`)));
   if(i%10===0)console.log(`Features ${label}: ${i}/60, ${((Date.now()-start)/1000).toFixed(1)}s`);
  }
 }
 console.log('Training classifier with official TeachableMobileNet.train()');
 const trainingLog=[];
 await teachable.train({denseUnits:100,learningRate:0.001,batchSize:16,epochs:50},{onEpochEnd:(epoch,logs)=>{trainingLog.push({epoch:epoch+1,...logs});if((epoch+1)%10===0)console.log('Epoch',epoch+1,JSON.stringify(logs));}});
 const out=path.join(root,'model');fs.mkdirSync(out,{recursive:true});
 await teachable.save({save:async a=>{
  fs.writeFileSync(path.join(out,'model.json'),JSON.stringify({format:'layers-model',generatedBy:'TensorFlow.js tfjs-layers v1.3.1',convertedBy:null,modelTopology:a.modelTopology,weightsManifest:[{paths:['weights.bin'],weights:a.weightSpecs}]}));
  fs.writeFileSync(path.join(out,'weights.bin'),Buffer.from(a.weightData));
  return {modelArtifactsInfo:{dateSaved:new Date(),modelTopologyType:'JSON',modelTopologyBytes:JSON.stringify(a.modelTopology).length,weightSpecsBytes:JSON.stringify(a.weightSpecs).length,weightDataBytes:a.weightData.byteLength}};
 }});
 fs.writeFileSync(path.join(out,'metadata.json'),JSON.stringify(metadata));
 const test=[];let correct=0;
 for(let c=0;c<3;c++){
  const label=metadata.labels[c];
  for(let i=61;i<=80;i++){
   const sample=await readPixels(path.join(root,'training',label,`${label.toLowerCase()}-${String(i).padStart(3,'0')}.png`));
   const probabilities=teachable.asSequentialModel.predict(sample);const values=Array.from(probabilities.dataSync());const top=values.indexOf(Math.max(...values));
   if(top===c)correct++;
   test.push({file:`${label}/${i}`,expected:label,predicted:metadata.labels[top],probability:values[top],probabilities:values});sample.dispose();probabilities.dispose();
  }
 }
 const cards=[];
 for(const [name,label]of [['red','Red'],['blue','Blue'],['neutral','Neutral']]){const sample=await readPixels(path.join(root,name+'-card.png'));const p=teachable.asSequentialModel.predict(sample);const values=Array.from(p.dataSync());cards.push({card:name,expected:label,probabilities:values});sample.dispose();p.dispose();}
 const report={trainingRoute:metadata.userMetadata.trainingRoute,trainingSamples:180,testSamples:60,correct,accuracy:correct/60,labels:metadata.labels,training:trainingLog,cards,test};
 fs.writeFileSync(path.join(root,'model-validation.json'),JSON.stringify(report,null,2));
 console.log('FINISHED',JSON.stringify({accuracy:report.accuracy,cards,weightsBytes:fs.statSync(path.join(out,'weights.bin')).size}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
